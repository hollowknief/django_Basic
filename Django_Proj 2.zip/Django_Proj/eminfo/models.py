from django.db import models
from django.urls import reverse
# Create your models here.
class Employee(models.Model):
    name=models.CharField(max_length=50)
    emp_id=models.IntegerField(primary_key=True)
    mobno=models.IntegerField()
    addr=models.CharField(max_length=100)
    domain=models.CharField(max_length=20)
    pos=models.CharField(max_length=30)


