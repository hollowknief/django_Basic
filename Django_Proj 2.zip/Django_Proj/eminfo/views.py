from django.shortcuts import render,redirect
from django.http import HttpResponse,JsonResponse
from .forms import Employeeform
from eminfo.models import Employee

from django.contrib.auth.models import User
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
import json
# Create your views here.
global count
count=0



def employee(request):


    eform = Employeeform(request.POST)
    if request.method=='POST':
        if eform.is_valid():
            eform.save()

        return redirect('/eminfo/page')
    return render(request,'index.html',{'form':eform})

def edit(request,id):
    global count
    countobb=counter.objects.latest('count')
    count=countobb.count
    print(count)
    employ= Employee.objects.get(id=id)
    form = Employeeform(request.POST, instance=employ)
    if form.is_valid():
        form.save()
        return redirect('/eminfo/page')
    count+=1
    countobj=counter.objects.create(count=count)
    countobj.save()
    return render(request, 'edit.html', {'employee': employ})

def delemployee(request,id):
    xp=Employee.objects.get(id=id)
    context={'em':xp}
    xp.delete()
    return render(request,'display.html',context)

def page(request):
    text = Employee.objects.all()
    count = Employee.objects.count()
    page_h = Paginator(text, 8)
    page_num=request.GET.get('page')
    club = page_h.get_page(page_num)
    context = {'club': club, 'counts': count}
    if request.method == 'POST' and 'delete' in request.POST:
        data_list = request.POST.getlist('delete')
        print(data_list)
        for i in data_list:
            if i.isdigit():
                Employee.objects.get(id=i).delete()
        count = Employee.objects.count()
        context = { 'counts': count}
        return redirect('/eminfo/page',context)



    return render(request,'page.html',context)





