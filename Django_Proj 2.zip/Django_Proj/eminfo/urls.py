from django.conf.urls import url,include
from django.urls import include, path
from . import views
urlpatterns=[
    path('employee/',views.employee,name='employee'),
    path('page/',views.page,name='count_data'),
    path('edit/<int:id>',views.edit,name='show'),
    path('display/<int:id>',views.delemployee,name='delemployee'),

]